package com.tigrex.rules.authorize.config;

import org.springframework.context.annotation.Configuration;

/**
 * @author linus
 */
@Configuration
public class FeignConfig {
}
