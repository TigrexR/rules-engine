package com.tigrex.rules.processor.service;

/**
 * @author linus
 */
public interface GroovyScriptService {
}
